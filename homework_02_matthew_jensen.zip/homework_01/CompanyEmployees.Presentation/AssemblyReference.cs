﻿namespace CompanyEmployees.Presentation // do I need this namespace?
{
    public static class AssemblyReference
    {

    }
}